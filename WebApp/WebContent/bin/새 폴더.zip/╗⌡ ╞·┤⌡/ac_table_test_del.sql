
------------------
alter table ac_reservation drop constraint ac_reservation_fk_user_passNo;
alter table ac_reservation drop constraint ac_reservation_fk_flightNo;
alter table ac_reservation2 drop constraint ac_reservation2_fk_resNo;
alter table ac_blacklist drop constraint ac_blacklist_fk_user_passNo;
alter table ac_seat drop constraint ac_seat_fk_resNo;
alter table ac_company drop constraint ac_company_fk_resNo;
alter table ac_flight drop constraint ac_flight_fk_regNo;
alter table ac_flight drop constraint ac_flight_fk_dep;
alter table ac_flight drop constraint ac_flight_fk_des;


drop table ac_user;
drop table ac_blacklist;
drop table ac_blacklist2;
drop table ac_reservation;
drop table ac_seat;
drop table ac_company;
drop table ac_aircraft;
drop table ac_flight;
drop table ac_dep;
drop table ac_des;
drop table ac_employee;
drop table ac_onboard_emp;

purge recyclebin;