select * from ac_user;

insert into ac_user values (100, 'M11111', 'dkdlel', '1234', '�質��', 'KIM NANA', to_date('20000101','YYMMDD'),
'F', 'KOREA', '010-5555-8888', 'nana@naver.com', '2000', 'white');

commit;


update ac_user set userNo=100, user_name='�質��', user_birth='19900707',
user_ename='KIM NANA', user_gender='F', user_tel='010-7777-8888', user_passNo='M25877',
user_email='dada@naver.com', mileage='2000', grade='white' where userNo=100;

select * from ac_user;
select * from ac_blacklist;
select * from ac_blacklist2;

--"ȸ����ȣ", "�̸�(�ѱ�)", "�̸�(����)", "���ǹ�ȣ", "����", "����"
select userNo, user_name, user_ename, u.user_passNo, user_gender, reason from ac_user u join ac_blacklist b on u.user_passNo=b.user_passNo
union all
select userNo, black_name, black_ename, black_passNo, black_gender, reason from ac_blacklist2;

select userNo, user_name, user_ename, u.user_passNo, user_gender, reason
from ac_user u join ac_blacklist b on u.user_passNo=b.user_passNo
union all
select userNo, black_name, black_ename, black_passNo,
black_gender, reason from ac_blacklist2;

select user_name, user_ename, u.user_passNo, user_gender, user_birth, reason
from ac_user u join ac_blacklist b on u.user_passNo=b.user_passNo where u.user_passNo='M112345';

select black_name, black_ename, black_passNo, black_gender, black_birth, reason
from ac_blacklist2 where black_passNo='M378749';

select * from ac_blacklist;
select * from ac_blacklist2;

select userNo, user_name as name, user_ename, u.user_passNo, user_gender, reason
from ac_user u join ac_blacklist b on u.user_passNo=b.user_passNo
union all
select userNo, black_name as name, black_ename, black_passNo,
black_gender, reason from ac_blacklist2 order by name;

select user_name as name, user_ename, u.user_passNo, user_gender, reason, userNo
from ac_user u join ac_blacklist b on u.user_passNo=b.user_passNo
union all
select black_name as name, black_ename, black_passNo,
black_gender, reason, userNo from ac_blacklist2 order by name;

insert into ac_blacklist2 (black_passNo, black_name, black_ename, black_birth, black_gender, black_exDate, reason, userNo, regDate)
values('M45454', '�̻���', 'LEE SANGJUN', to_date('19950105', 'YYMMDD'), 'M', to_date('20230701', 'YYMMDD'), '���� �̳���', null, sysdate);


insert into ac_blacklist2 (black_passNo, black_name, black_ename, black_birth, black_gender, black_exDate, reason)
values('M45454', '�̻���', 'LEE SANGJUN', to_date('19950105', 'YYMMDD'), 'M', to_date('20230701', 'YYMMDD'), '���� �̳���');

insert into ac_blacklist2 values('M7877', '�ƾƾ�', 'LEE SANGJUN', to_date('19950105', 'YYMMDD'), 'M', to_date('20230701', 'YYMMDD'), '���� �̳���');

delete from ac_blacklist2;

select * from ac_user;
delete from ac_user where userNo=40;
select * from ac_blacklist;
delete from ac_blacklist2;
commit;

select * from ac_user;
update ac_user set userNo=1, user_name='����', user_birth=to_date('19910402','yymmdd'),
user_ename='YUN MIN', user_gender='M', user_tel='010-1111-2222', user_passNo='M565462',
user_email='dbsals@naver.com', mileage='5375', grade='white' where userNo=1;

select to_char(max(user_birth), 'yyyy-mm-dd'), to_char(min(user_birth), 'yyyy-mm-dd') from ac_user;

----------------------------------------------------------------------------

-- SALES
select * from ac_flight;
select * from ac_reservation order by brdDate;

select brdDate, f.flightNo, dep, des, fare*0.04, fare, fare-(fare*0.04)
from ac_flight f join ac_reservation r on f.flightNo=r.flightNo order by brdDate;

select brdDate from ac_reservation order by brdDate;
select trunc((to_date('20201210', 'yymmdd')), 'mm') from dual;
select trunc(sysdate,'mm') from dual;
select to_date((sysdate)-1) from dual;
select brdDate from ac_reservation where trunc(sysdate, 'month')<=brdDate order by brdDate;
select brdDate from ac_reservation where brdDate<to_date((sysdate)-1);


select brdDate from ac_reservation where trunc((to_date('20201210','yymmdd')), 'mm')<=brdDate and brdDate<last_day('20201210') order by brdDate;

select brdDate from ac_reservation where trunc(sysdate, 'mm')<=brdDate order by brdDate;    --21/02/15~21/12/01 ..? �� 2/15������..?

select to_date(sysdate)-1 from dual;
select brdDate from ac_reservation where brdDate<to_date(sysdate)-1 order by brdDate;       --19/08/01~21/01/10 ok

select brdDate from ac_reservation where trunc(sysdate, 'mm')<=brdDate and brdDate<to_date(sysdate)-1 order by brdDate;

SELECT TO_CHAR(TRUNC(SYSDATE,'MM'),'YYYYMMDD') FROM DUAL;


-- �̹��� 1�Ϻ��� ���ϱ����� ���� --> �ٽ� Ȯ��! trunc(sysdate, 'mm')<=brdDate �κ� �̻���..
select brdDate, f.flightNo, dep, des, fare*0.04, fare, fare-(fare*0.04)
from ac_flight f join ac_reservation r on f.flightNo=r.flightNo
where brdDate between trunc(sysdate, 'mm') and to_date(sysdate)-1
order by brdDate;

select brdDate, f.flightNo, dep, des, fare*0.04, fare, fare-(fare*0.04)
from ac_flight f join ac_reservation r on f.flightNo=r.flightNo
where brdDate between trunc((to_date('20201210','yymmdd')), 'mm') and last_day('20201210')
order by brdDate;

-- ��¥�� �˻�
select to_char(brdDate, 'YYYY-MM-DD'), f.flightNo, dep, des, to_char(fare*0.04, 'L9,999,999'),
to_char(fare, 'L9,999,999'), to_char(fare-(fare*0.04), 'L9,999,999')
from ac_flight f join ac_reservation r on f.flightNo=r.flightNo
where brdDate between to_date('20191001', 'YYMMDD') and to_date('20201231', 'YYMMDD')
order by brdDate;

--------------------------------------------------------
-- ������Ʈ
select * from ac_reservation;   --�����ȣ/������/����/ž����/���ǹ�ȣ/���Ǹ�����
select * from ac_company;       --���ǹ�ȣ/�̸�/������/�������/����/���Ǹ�����/����/����ó/�̸���/�����ȣ

-- ���ɴ뺰 �̿�� ���ϱ�
-- ������Ϸ� ���� ���
select months_between(trunc(sysdate, 'year'), trunc(to_date('19890416','yymmdd'), 'year')) / 12+1 age from dual;
select months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year')) / 12+1 age from ac_user;

select user_name, user_birth, resNo from ac_user u join ac_reservation r
on u.user_passNo = r.user_passNo;

select * from ac_userage;
-- ���ɴ� ��� (���ɴ� ���̺� ����)
select user_name, user_birth, resNo,
months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 age,
ageGroup from ac_user u, ac_reservation r, ac_userAge a
where u.user_passNo = r.user_passNo
and months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 between startAge and endAge
union all
select com_name, com_birth, c.resNo,
months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 age,
ageGroup from ac_company c, ac_reservation r, ac_userAge a
where c.resNo = r.resNo
and months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 between startAge and endAge order by user_name;

-- agegroup�� ������ ��
select ageGroup, count(ageGroup)
from (select user_name, user_birth, resNo,
months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 age,
ageGroup from ac_user u, ac_reservation r, ac_userAge a
where u.user_passNo = r.user_passNo
and months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 between startAge and endAge
union all
select com_name, com_birth, c.resNo,
months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 age,
ageGroup from ac_company c, ac_reservation r, ac_userAge a
where c.resNo = r.resNo
and months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 between startAge and endAge order by user_name)
group by ageGroup;

-- ��¥ ���� + ���� + ���ɴ� �� ������ ��
select brdDate, user_name, user_birth, resNo,
months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 age, ageGroup, dep, des
from ac_user u, ac_reservation r, ac_userAge a, ac_flight f
where u.user_passNo = r.user_passNo
and r.flightNo = f.flightNo
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd')
and months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 between startAge and endAge
union all
select brdDate, com_name, com_birth, c.resNo,
months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 age, ageGroup, dep, des
from ac_company c, ac_reservation r, ac_userAge a, ac_flight f
where c.resNo = r.resNo
and r.flightNo = f.flightNo
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd')
and months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 between startAge and endAge order by dep;

-------------------------------------------------------------
-- 1. ��¥ ���� + ���ɴ� ���� ������ ��      -- 21�� (20�� : 6 / 30�� : 11 / 40�� : 4)
select ageGroup, count(ageGroup)
from (select months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 age, ageGroup
from ac_user u, ac_reservation r, ac_userAge a
where u.user_passNo = r.user_passNo
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd')
and agegroup between 20 and 40
and months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 between startAge and endAge
union all
select months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 age, ageGroup
from ac_company c, ac_reservation r, ac_userAge a
where c.resNo = r.resNo
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd')
and agegroup between 20 and 40
and months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 between startAge and endAge)
group by ageGroup;

-- 2. ���� ���� + ���ɴ� ���� ������ ��      -- 5�� (20�� : 1 / 30�� : 1 / 40�� : 3)
select ageGroup, count(ageGroup)
from (select months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 age, ageGroup
from ac_user u, ac_reservation r, ac_userAge a, ac_flight f
where u.user_passNo = r.user_passNo
and r.flightNo = f.flightNo
and agegroup between 20 and 40
and dep='SYD' and des='ICN'
and months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 between startAge and endAge
union all
select months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 age, ageGroup
from ac_company c, ac_reservation r, ac_userAge a, ac_flight f
where c.resNo = r.resNo
and r.flightNo = f.flightNo
and agegroup between 20 and 40
and dep='SYD' and des='ICN'
and months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 between startAge and endAge)
group by ageGroup;

-- 3. ��¥ ���� + ���� ���� + ���ɴ� ���� ������ ��      -- 3�� (20�� : 1 / 40�� : 2)
select ageGroup, count(ageGroup)
from (select months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 age, ageGroup
from ac_user u, ac_reservation r, ac_userAge a, ac_flight f
where u.user_passNo = r.user_passNo
and r.flightNo = f.flightNo
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd')
and agegroup between 20 and 40
and dep='SYD' and des='ICN'
and months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 between startAge and endAge
union all
select months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 age, ageGroup
from ac_company c, ac_reservation r, ac_userAge a, ac_flight f
where c.resNo = r.resNo
and r.flightNo = f.flightNo
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd')
and agegroup between 20 and 40
and dep='SYD' and des='ICN'
and months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 between startAge and endAge)
group by ageGroup;

-- 4. ��¥ ���� + ���� ������ ��      -- 23�� (M : 17 / F : 6)
select user_gender, count(user_gender)
from (select user_name, user_gender
from ac_user u, ac_reservation r
where u.user_passNo=r.user_passNo
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd')
union all
select com_name, com_gender
from ac_company c, ac_reservation r
where c.resNo=r.resNo
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd'))
group by user_gender;

-- 5. ���� ���� + ���� ������ ��      -- 7�� (M : 5 / F : 2)
select user_gender, count(user_gender)
from (select user_name, user_gender
from ac_user u, ac_reservation r, ac_flight f
where u.user_passNo=r.user_passNo
and r.flightNo = f.flightNo
and dep='SYD' and des='ICN'
union all
select com_name, com_gender
from ac_company c, ac_reservation r, ac_flight f
where c.resNo=r.resNo
and r.flightNo = f.flightNo
and dep='SYD' and des='ICN')
group by user_gender;

-- 6. ��¥ ���� + ���� ���� + ���� ������ ��      -- 4�� (M : 3 / F : 1)
select user_gender, count(user_gender)
from (select user_name, user_gender
from ac_user u, ac_reservation r, ac_flight f
where u.user_passNo=r.user_passNo
and r.flightNo = f.flightNo
and dep='SYD' and des='ICN'
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd')
union all
select com_name, com_gender
from ac_company c, ac_reservation r, ac_flight f
where c.resNo=r.resNo
and r.flightNo = f.flightNo
and dep='SYD' and des='ICN'
and brdDate between to_date('20201001','yymmdd') and to_date('20201231','yymmdd'))
group by user_gender;





select ageGroup, count(ageGroup)
from (select months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 age, ageGroup
from ac_user u, ac_reservation r, ac_userAge a
where u.user_passNo = r.user_passNo
and brdDate between to_date('2020/10/01','yymmdd') and to_date('2020/12/31','yymmdd')
and agegroup between 20 and 40
and months_between(trunc(sysdate, 'year'), trunc(user_birth, 'year'))/12+1 between startAge and endAge
union all
select months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 age, ageGroup
from ac_company c, ac_reservation r, ac_userAge a
where c.resNo = r.resNo
and brdDate between to_date('2020/10/01','yymmdd') and to_date('2020/12/31','yymmdd')
and agegroup between 20 and 40
and months_between(trunc(sysdate, 'year'), trunc(com_birth, 'year'))/12+1 between startAge and endAge)
group by ageGroup;

